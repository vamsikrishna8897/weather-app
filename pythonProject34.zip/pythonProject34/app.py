from flask import Flask, request, render_template
import requests

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/weather', methods=['POST'])
def weather():
    city = request.form['city']
    api_key = '30d4741c779ba94c470ca1f63045390a'
    base_url = 'http://api.openweathermap.org/data/2.5/weather'
    complete_url = f'{base_url}?appid={api_key}&q={city}'
    response = requests.get(complete_url)
    data = response.json()
    if data.get('cod') != '404':
        if 'main' in data and 'temp' in data['main']:
            temp = round(data['main']['temp'] - 273.15, 1)
            humidity = data['main']['humidity']
            description = data['weather'][0]['description']
            message = f'city:{city},Temperature: {temp} °C, Humidity: {humidity}%, Description: {description}'
        else:
            message = 'Error: Unable to retrieve temperature and humidity data from the API response.'
    else:
        message = 'Error: City not found.'
    return render_template('index.html', message=message)
if __name__ == '__main__':
    app.run(debug=True)